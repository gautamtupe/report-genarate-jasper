package com.generate.report.services;
import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.generate.report.dao.EmployeeDao;
import com.generate.report.model.Employee;
import com.generate.report.model.EmployeeReport;
import com.generate.report.repository.EmployeeRepository;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	EmployeeDao employeedao;
	
	@Override
	public List<Employee> getAllEmployee() {
		return employeeRepository.findAll();
	}


	@Override
	public String employeeReport() {
		String ProjectPath = new File("").getAbsolutePath();
		System.out.println(ProjectPath);
		String employeeReportFilePath ="E:\\Home\\Gauti\\Projects\\expense\\backend\\generate-report\\src\\main\\resources\\report-templates\\employee.jrxml";
		System.out.println(employeeReportFilePath);
//		
		try {
			
//			List<EmployeeReport> empList = Arrays.asList(new EmployeeReport(
//					1,"Gautama","raosaheb","Tupe",101,"Gautama raosaheb Tupe")
//					);
//			
			List<EmployeeReport> empList = employeedao.getAllEmployeeData();
			
			// Compile the Jasper report from .jrxml to .japser
			JasperReport jasperReport=JasperCompileManager.compileReport(employeeReportFilePath);
			
			// Get your data source
			JRBeanCollectionDataSource jrBeanCollectionDataSource=new JRBeanCollectionDataSource(empList);
			
			
			//All Parameters
			Map<String, Object> parameters = new HashMap<>();
			
			parameters.put("createdBy", "Gautam Tupe");
			
			// Fill the report
			JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, parameters, jrBeanCollectionDataSource);
				
			// Export the report to a PDF file
			JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\Home\\Gauti\\Projects\\expense\\examples\\employee.pdf");
			System.out.println("Done");
			
			return "Report successfully generated @path= =============================================";
		
		} catch (Exception e) {
			e.getMessage();
			return e.getMessage();
		}
		
		
//		
		
		
	//	return employeeRepository.findAll();
	}
	
	

}
