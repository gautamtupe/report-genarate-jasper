package com.generate.report.services;

import java.util.List;

import com.generate.report.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployee();

	String employeeReport();

}
