package com.generate.report.model;

public class EmployeeReport {
	private long employeeId;
	private String firstName;
	private String middleName;
	private String lastName;
	private long departmentId;
	private String fullName;
	
	
	public EmployeeReport() {
		// TODO Auto-generated constructor stub
	}
	public EmployeeReport(long employeeId, String firstName, String middleName, String lastName, long departmentId,
			String fullName) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.departmentId = departmentId;
		this.fullName = fullName;
	}
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	
}
