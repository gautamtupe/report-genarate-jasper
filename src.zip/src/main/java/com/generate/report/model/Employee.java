package com.generate.report.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "M_EMPLOYEE")
@JsonInclude(Include.NON_NULL)
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "M_EMPLOYEE_S")
	@SequenceGenerator(name = "M_EMPLOYEE_S", sequenceName = "M_EMPLOYEE_SEQUENCE", allocationSize = 1)
	@Column(name = "EMPLOYEEID", updatable = false, nullable = false)
	private long employeeId;
	
	@Column(name = "FIRSTNAME")
	private String firstName;

	@Column(name = "MIDDLENAME")
	private String middleName;

	@Column(name = "LASTNAME")
	private String lastName;
	
	@Column(name = "DEPARTMENTID")
	private long departmentId;

	@Transient
	private String fullName;

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(long employeeId, String firstName, String middleName, String lastName, long departmentId,
			String fullName) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.departmentId = departmentId;
		this.fullName = fullName;
	}
	
	
}
