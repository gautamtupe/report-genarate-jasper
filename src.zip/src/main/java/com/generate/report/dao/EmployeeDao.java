package com.generate.report.dao;

import java.util.List;

import com.generate.report.model.EmployeeReport;

public interface EmployeeDao {

	List<EmployeeReport> getAllEmployeeData();

}
